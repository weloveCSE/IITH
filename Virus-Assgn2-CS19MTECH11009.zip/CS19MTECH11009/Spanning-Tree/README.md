g++ -std=c++11 Virus2-CS19MTECH11009.cpp -lpthread -o out
./out >output.txt
