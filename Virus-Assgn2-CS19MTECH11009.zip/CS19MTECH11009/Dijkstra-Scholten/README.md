FOr Dijkstra-Scholton algorithm we dont need static Spanning tree so please delete the spanning tree detains in the input file

g++ -std=c++11 Virus1-CS19MTECH11009.cpp -lpthread -o out
./out >output.txt
