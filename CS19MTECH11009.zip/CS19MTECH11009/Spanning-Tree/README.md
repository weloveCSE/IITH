g++ -std=c++11 CS19MTECH11009_TD_2.cpp -lpthread
./a.out >output.txt
